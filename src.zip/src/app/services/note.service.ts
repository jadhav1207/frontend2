import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Note {
  id?: number;
  title: string;
  content: string;
  category?: 'WORK' | 'PERSONAL' | 'STUDY' | 'OTHER';
  createdAt?: string;
  updatedAt?: string;
}

@Injectable({
  providedIn: 'root'
})
export class NoteService {
  private apiUrl = 'http://localhost:8081/api/notes';

  constructor(private http: HttpClient) {}

  createNote(note: Note, userId: number): Observable<Note> {
    const headers = new HttpHeaders().set('UserId', userId.toString());
    return this.http.post<Note>(this.apiUrl, note, { headers });
  }

  getNotes(userId: number): Observable<Note[]> {
    const headers = new HttpHeaders().set('UserId', userId.toString());
    return this.http.get<Note[]>(this.apiUrl, { headers });
  }

  updateNote(noteId: number, note: Note, userId: number): Observable<string> {
    const headers = new HttpHeaders().set('UserId', userId.toString());
    return this.http.put<string>(`${this.apiUrl}/${noteId}`, note, { 
      headers, 
      responseType: 'text' as 'json' 
    });
  }

  deleteNote(noteId: number, userId: number): Observable<string> {
    const headers = new HttpHeaders().set('UserId', userId.toString());
    return this.http.delete<string>(`${this.apiUrl}/${noteId}`, { 
      headers, 
      responseType: 'text' as 'json' 
    });
  }

  deleteMultipleNotes(noteIds: number[], userId: number): Observable<string> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'UserId': userId.toString()
    });
    return this.http.request<string>('DELETE', `${this.apiUrl}/bulk`, {
      headers,
      body: noteIds,
      responseType: 'text' as 'json'
    });
  }
}