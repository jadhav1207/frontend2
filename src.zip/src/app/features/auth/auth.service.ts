import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';// API CALL TO BACKEND
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';// Import tap operator for side effects , SAVING USER TO LOCAL STORAGE

export interface User { // define data shape get back from backend
  id: number;
  username: string;
  email: string;
  password?: string;
  role: 'USER' | 'ADMIN';
}

export interface LoginRequest { //define data shape to send to backend
  username: string;
  password: string;
}

export interface RegisterRequest {//define data shape to send to backend
  username: string;
  email: string;
  password: string;
  role?: 'USER' | 'ADMIN';
}

@Injectable({ //  make service available application-wide
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:8081/api/auth';
  private currentUserSubject = new BehaviorSubject<User | null>(null);// BehaviorSubject to hold current user
  public currentUser$ = this.currentUserSubject.asObservable();// Observable for current user --- components can subscribe to user change

  constructor(private http: HttpClient) {
    const storedUser = localStorage.getItem('currentUser');// Check for existing user in localStorage
    if (storedUser) {
      try {
        this.currentUserSubject.next(JSON.parse(storedUser)); // Initialize current user from localStorage
      } catch (e) {
        localStorage.removeItem('currentUser');// Remove invalid data
      }
    }
  }

  login(loginData: LoginRequest): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/login`, loginData, {
      responseType: 'json'
    }).pipe(
      tap(user => {
        localStorage.setItem('currentUser', JSON.stringify(user));// Store user in localStorage
        this.currentUserSubject.next(user);// Update current user to keep current user logged in across page refreshes
      })
    );
  }

  register(registerData: RegisterRequest): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/register`, registerData, {
      responseType: 'json'
    });
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    const user = this.getCurrentUser();
    const storedUser = localStorage.getItem('currentUser');
    return user !== null && storedUser !== null;
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'ADMIN';
  }

  isUser(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'USER';
  }
}
