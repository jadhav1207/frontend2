import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../../auth/auth.service';
import { Router } from '@angular/router';
import { NoteService, Note } from '../../../services/note.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: false,
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {
  Math = Math;
  currentUser: User | null = null;
  showNotesList = false;
  showCreateNoteForm = false;
  showEditNoteForm = false;
  notes: Note[] = [];
  selectedNotes: number[] = [];
  editingNote: Note | null = null;
  isLoading = false;
  deleteMode = false;
  message = '';
  sortColumn = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  filteredNotes: Note[] = [];
  currentPage = 0;
  pageSize = 10;
  totalNotes = 0;
  paginatedNotes: Note[] = [];
  menuVisible = false;

  
  constructor(
    private authService: AuthService,
    private router: Router,
    private noteService: NoteService
  ) {}

  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    // Show notes by default
    this.showNotes();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  showNotes() {
    if (!this.currentUser?.id) return;
    
    this.showNotesList = true;
    this.showCreateNoteForm = false;
    this.showEditNoteForm = false;
    this.isLoading = true;
    
    this.noteService.getNotes(this.currentUser.id).subscribe({
      next: (notes) => {
        this.notes = notes;
        this.filteredNotes = [...notes];
        this.totalNotes = notes.length;
        this.updatePaginatedNotes();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error fetching notes:', error);
        this.isLoading = false;
      }
    });
  }
  showCreateNote() {
    this.showCreateNoteForm = true;
    this.showNotesList = false;
    this.showEditNoteForm = false;
  }

  hideCreateNote() {
    this.showCreateNoteForm = false;
  }

  createNote(title: string, content: string, category: string = 'OTHER') {
    if (!this.currentUser?.id) return;
    
    this.isLoading = true;
    const note: Note = { title, content, category: category as any };
    
    this.noteService.createNote(note, this.currentUser.id).subscribe({
      next: (createdNote) => {
        this.isLoading = false;
        this.hideCreateNote();
        this.showNotes();
        this.showMessage(typeof createdNote === 'string' ? createdNote : 'Note created successfully');
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error creating note');
      }
    });
  }

  editNote(note: Note) {
    this.editingNote = { ...note };
    this.showEditNoteForm = true;
    this.showNotesList = false;
    this.showCreateNoteForm = false;
  }

  updateNote(title: string, content: string, category: string = 'OTHER') {
    if (!this.currentUser?.id || !this.editingNote?.id) return;
    
    console.log('Updating note:', this.editingNote.id);
    console.log('User ID:', this.currentUser.id);
    console.log('Updated data:', { title, content, category });
    
    this.isLoading = true;
    const updatedNote: Note = { title, content, category: category as any };
    console.log('Updated note object:', updatedNote);
    
    this.noteService.updateNote(this.editingNote.id, updatedNote, this.currentUser.id).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.hideEditNote();
        this.showNotes();
        this.showMessage(response);
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error updating note');
      }
    });
  }

  hideEditNote() {
    this.showEditNoteForm = false;
    this.editingNote = null;
  }

  toggleNoteSelection(noteId: number) {
    const index = this.selectedNotes.indexOf(noteId);
    if (index > -1) {
      this.selectedNotes.splice(index, 1);
    } else {
      this.selectedNotes.push(noteId);
    }
  }

  deleteSelectedNotes() {
    if (!this.currentUser?.id || this.selectedNotes.length === 0) return;
    
    console.log('Selected notes for deletion:', this.selectedNotes);
    console.log('Current user:', this.currentUser);
    
    if (!confirm(`Delete ${this.selectedNotes.length} selected notes?`)) return;
    
    this.isLoading = true;
    this.noteService.deleteMultipleNotes(this.selectedNotes, this.currentUser.id).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.selectedNotes = [];
        this.showNotes();
        this.showMessage(response);
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error deleting notes');
      }
    });
  }

  toggleDeleteMode() {
    this.deleteMode = !this.deleteMode;
    if (!this.deleteMode) {
      this.selectedNotes = [];
    }
  }

  deleteNote(noteId: number) {
    if (!this.currentUser?.id) return;
    
    if (!confirm('Delete this note?')) return;
    
    this.isLoading = true;
    this.noteService.deleteNote(noteId, this.currentUser.id).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.showNotes();
        this.showMessage('Note deleted successfully');
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error deleting note');
      }
    });
  }

  updatePaginatedNotes() {
    if (this.pageSize === -1) {
      this.paginatedNotes = this.filteredNotes;
    } else {
      const startIndex = this.currentPage * this.pageSize;
      const endIndex = startIndex + this.pageSize;
      this.paginatedNotes = this.filteredNotes.slice(startIndex, endIndex);
    }
  }

  changePageSize(event: any) {
    this.pageSize = parseInt(event.target.value);
    this.currentPage = 0;
    this.updatePaginatedNotes();
  }

  getPageNumbers(): number[] {
    if (this.pageSize === -1) return [];
    const totalPages = Math.ceil(this.totalNotes / this.pageSize);
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }

  goToPage(page: number) {
    this.currentPage = page - 1;
    this.updatePaginatedNotes();
  }

  sort(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    
    this.filteredNotes.sort((a, b) => {
      let aVal = (a as any)[column];
      let bVal = (b as any)[column];
      
      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }
      
      if (aVal < bVal) return this.sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
    
    this.currentPage = 0;
    this.updatePaginatedNotes();
  }

  nextPage() {
    if ((this.currentPage + 1) * this.pageSize < this.totalNotes) {
      this.currentPage++;
      this.updatePaginatedNotes();
    }
  }

  prevPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.updatePaginatedNotes();
    }
  }

  toggleMenu() {
    this.menuVisible = !this.menuVisible;
  }

  showMessage(msg: string) {
    this.message = msg;
    setTimeout(() => this.message = '', 3000);
  }
}