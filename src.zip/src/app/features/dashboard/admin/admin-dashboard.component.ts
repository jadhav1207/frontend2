import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../../auth/auth.service';
import { Router } from '@angular/router';
import { NoteService, Note } from '../../../services/note.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: false,
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {
  currentUser: User | null = null;
  showNotesList = false;
  showCreateNoteForm = false;
  showEditNoteForm = false;
  notes: Note[] = [];
  selectedNotes: number[] = [];
  editingNote: Note | null = null;
  isLoading = false;
  deleteMode = false;
  message = '';
  
  constructor(
    private authService: AuthService,
    private router: Router,
    private noteService: NoteService
  ) {}

  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    
    // Show notes by default
    this.showNotes();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  showNotes() {
    if (!this.currentUser?.id) return;
    
    this.showNotesList = true;
    this.showCreateNoteForm = false;
    this.showEditNoteForm = false;
    this.isLoading = true;
    
    this.noteService.getNotes(this.currentUser.id).subscribe({
      next: (notes) => {
        this.notes = notes;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error fetching notes:', error);
        this.isLoading = false;
      }
    });
  }

  showCreateNote() {
    this.showCreateNoteForm = true;
    this.showNotesList = false;
    this.showEditNoteForm = false;
  }

  hideCreateNote() {
    this.showCreateNoteForm = false;
  }

  createNote(title: string, content: string, category: string = 'OTHER') {
    if (!this.currentUser?.id) return;
    
    this.isLoading = true;
    const note: Note = { title, content, category: category as any };
    
    this.noteService.createNote(note, this.currentUser.id).subscribe({
      next: (createdNote) => {
        this.isLoading = false;
        this.hideCreateNote();
        this.showMessage(typeof createdNote === 'string' ? createdNote : 'Note created successfully');
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error creating note');
      }
    });
  }

  editNote(note: Note) {
    this.editingNote = { ...note };
    this.showEditNoteForm = true;
    this.showNotesList = false;
    this.showCreateNoteForm = false;
  }

  updateNote(title: string, content: string, category: string = 'OTHER') {
    if (!this.currentUser?.id || !this.editingNote?.id) return;
    
    console.log('Updating note:', this.editingNote.id);
    console.log('User ID:', this.currentUser.id);
    console.log('Updated data:', { title, content, category });
    
    this.isLoading = true;
    const updatedNote: Note = { title, content, category: category as any };
    console.log('Updated note object:', updatedNote);
    
    this.noteService.updateNote(this.editingNote.id, updatedNote, this.currentUser.id).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.hideEditNote();
        this.showNotes();
        this.showMessage(response);
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error updating note');
      }
    });
  }

  hideEditNote() {
    this.showEditNoteForm = false;
    this.editingNote = null;
  }

  toggleNoteSelection(noteId: number) {
    const index = this.selectedNotes.indexOf(noteId);
    if (index > -1) {
      this.selectedNotes.splice(index, 1);
    } else {
      this.selectedNotes.push(noteId);
    }
  }

  deleteSelectedNotes() {
    if (!this.currentUser?.id || this.selectedNotes.length === 0) return;
    
    console.log('Selected notes for deletion:', this.selectedNotes);
    console.log('Current user:', this.currentUser);
    
    if (!confirm(`Delete ${this.selectedNotes.length} selected notes?`)) return;
    
    this.isLoading = true;
    this.noteService.deleteMultipleNotes(this.selectedNotes, this.currentUser.id).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.selectedNotes = [];
        this.showNotes();
        this.showMessage(response);
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error deleting notes');
      }
    });
  }

  toggleDeleteMode() {
    this.deleteMode = !this.deleteMode;
    if (!this.deleteMode) {
      this.selectedNotes = [];
    }
  }

  showMessage(msg: string) {
    this.message = msg;
    setTimeout(() => this.message = '', 3000);
  }
}