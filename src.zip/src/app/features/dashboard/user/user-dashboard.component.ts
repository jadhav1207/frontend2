import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../../auth/auth.service';
import { Router } from '@angular/router';
import { NoteService, Note } from '../../../services/note.service';

@Component({
  selector: 'app-user-dashboard',
  standalone: false,
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent implements OnInit {
  currentUser: User | null = null;
  showCreateNoteForm = false;
  showNotesList = false;
  showEditNoteForm = false;
  notes: Note[] = [];
  selectedNotes: number[] = [];
  editingNote: Note | null = null;
  isLoading = false;
  deleteMode = false;
  message = '';
  allNotes: Note[] = [];
  currentPage = 1;
  pageSize = 10;
  totalPages = 0;
  currentViewTitle = 'My Notes';
  currentCategory: string | null = null;
  
  constructor(
    private authService: AuthService,
    private router: Router,
    private noteService: NoteService
  ) {}

  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    console.log('Current user in dashboard:', this.currentUser);
    console.log('User ID:', this.currentUser?.id);
    console.log('Is logged in:', this.authService.isLoggedIn());
    console.log('LocalStorage user:', localStorage.getItem('currentUser'));
    
    // Show notes by default
    this.showNotes();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  showNotes() {
    if (!this.currentUser?.id) return;
    
    this.showNotesList = true;
    this.showCreateNoteForm = false;
    this.showEditNoteForm = false;
    this.isLoading = true;
    
    this.noteService.getNotes(this.currentUser.id).subscribe({
      next: (notes) => {
        this.notes = notes;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error fetching notes:', error);
        this.isLoading = false;
      }
    });
  }

  showCreateNote() {
    this.showCreateNoteForm = true;
    this.showNotesList = false;
    this.showEditNoteForm = false;
  }

  hideCreateNote() {
    this.showCreateNoteForm = false;
  }

  createNote(title: string, content: string, category: string = 'OTHER') {
    
    console.log('Creating note with user:', this.currentUser);
    
    if (!this.currentUser || !this.currentUser.id) {
      console.log('No user found, refreshing user data');
      this.currentUser = this.authService.getCurrentUser();
      
      if (!this.currentUser || !this.currentUser.id) {
        console.log('Please login again');
        return;
      }
    }
    
    this.isLoading = true;
    const note: Note = { title, content, category: category as any };
    
    this.noteService.createNote(note, this.currentUser.id).subscribe({
      next: (createdNote) => {
        this.isLoading = false;
        this.hideCreateNote();
        this.showMessage(typeof createdNote === 'string' ? createdNote : 'Note created successfully');
      },
      error: (error) => {
        this.isLoading = false;
        let errorMessage = 'Error creating note';
        
        if (typeof error.error === 'string') {
          errorMessage = error.error;
        } else if (error.error && typeof error.error === 'object') {
          errorMessage = JSON.stringify(error.error).replace(/[{}"]/g, '').replace(/:/g, ': ');
        } else if (error.message) {
          errorMessage = error.message;
        }
        
        this.showMessage(errorMessage);
      }
    });
  }

  editNote(note: Note) {
    this.editingNote = { ...note };
    this.showEditNoteForm = true;
    this.showNotesList = false;
    this.showCreateNoteForm = false;
  }

  updateNote(title: string, content: string, category: string = 'OTHER') {
    if (!this.currentUser?.id || !this.editingNote?.id) return;
    
    console.log('Update parameters:', { title, content, category });
    this.isLoading = true;
    const updatedNote: Note = { title, content, category: category as any };
    console.log('Updated note object:', updatedNote);
    
    this.noteService.updateNote(this.editingNote.id, updatedNote, this.currentUser.id).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.hideEditNote();
        this.showNotes();
        this.showMessage(response);
      },
      error: (error) => {
        this.isLoading = false;
        this.showMessage(error.error || error.message || 'Error updating note');
      }
    });
  }

  hideEditNote() {
    this.showEditNoteForm = false;
    this.editingNote = null;
  }

  toggleNoteSelection(noteId: number) {
    const index = this.selectedNotes.indexOf(noteId);
    if (index > -1) {
      this.selectedNotes.splice(index, 1);
    } else {
      this.selectedNotes.push(noteId);
    }
  }

  deleteSelectedNotes() {
    if (!this.currentUser?.id || this.selectedNotes.length === 0) return;
    
    if (!confirm(`Delete ${this.selectedNotes.length} selected notes?`)) return;
    
    this.isLoading = true;
    
    // For users, delete notes one by one since bulk delete is admin-only
    const deletePromises = this.selectedNotes.map(noteId => 
      this.noteService.deleteNote(noteId, this.currentUser!.id).toPromise()
    );
    
    Promise.all(deletePromises).then((responses) => {
      this.isLoading = false;
      this.selectedNotes = [];
      this.showNotes();
      this.showMessage('Notes deleted successfully');
    }).catch((error) => {
      this.isLoading = false;
      this.showMessage(error.error || error.message || 'Error deleting notes');
    });
  }

  toggleDeleteMode() {
    this.deleteMode = !this.deleteMode;
    if (!this.deleteMode) {
      this.selectedNotes = [];
    }
  }

  showMessage(msg: string) {
    this.message = msg;
    setTimeout(() => this.message = '', 3000);
  }
}