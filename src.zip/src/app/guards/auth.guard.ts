import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../features/auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  canActivate(): boolean {
    console.log('AuthGuard: Checking authentication');
    console.log('AuthGuard: isLoggedIn =', this.authService.isLoggedIn());
    console.log('AuthGuard: currentUser =', this.authService.getCurrentUser());
    
    if (this.authService.isLoggedIn()) {
      return true;
    }
    
    console.log('AuthGuard: Redirecting to login');
    this.router.navigate(['/login']);
    return false;
  }
}