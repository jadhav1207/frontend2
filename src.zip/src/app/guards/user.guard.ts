import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../features/auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserGuard implements CanActivate {
  
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  canActivate(): boolean {
    console.log('UserGuard: Checking user role');
    console.log('UserGuard: isUser =', this.authService.isUser());
    console.log('UserGuard: isAdmin =', this.authService.isAdmin());
    console.log('UserGuard: currentUser =', this.authService.getCurrentUser());
    
    if (this.authService.isUser()) {
      return true;
    }
    
    if (this.authService.isAdmin()) {
      console.log('UserGuard: Redirecting to admin dashboard');
      this.router.navigate(['/admin-dashboard']);
    } else {
      console.log('UserGuard: Redirecting to login');
      this.router.navigate(['/login']);
    }
    return false;
  }
}